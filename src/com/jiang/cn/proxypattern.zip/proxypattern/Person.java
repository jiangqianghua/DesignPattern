package com.jiang.cn.proxypattern;

public interface Person {
    void searchHome();
}
