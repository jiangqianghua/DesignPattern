package com.jiang.cn.proxypattern.jdkproxy;

public interface Person {
    void searchHome();
}
