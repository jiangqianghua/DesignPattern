package com.jiang.cn.proxypattern;

import com.jiang.cn.proxypattern.myproxy.JProxy;
import com.jiang.cn.proxypattern.myproxy.MyClassLoader;
import com.jiang.cn.proxypattern.myproxy.MyInvovationHandler;

import java.lang.reflect.Method;

public class HomeLink implements MyInvovationHandler{

    private Person target ;

    public Object getInstance(Person target){
        this.target = target ;
        Class clazz = target.getClass();
        Object obj = JProxy.newProxyInstance(new MyClassLoader(),clazz.getInterfaces(),this);
        return obj ;
    }

    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        System.out.println("我是链家的房子");
        method.invoke(target,args);
        System.out.println("我是链接，房子已经找完了");
        return null;
    }
}
